#ifndef USERFUNCTIONS_H
#define USERFUNCTIONS_H

double u_InitTemperature(double x, double y, double z);

#endif

